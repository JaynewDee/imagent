"""
This module is responsible for reading and writing to the filesystem.
"""
