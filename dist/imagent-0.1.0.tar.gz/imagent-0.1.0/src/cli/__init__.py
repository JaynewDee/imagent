"""
This module is responsible for managing user input from the command-line.
"""
