import click


@click.command()
@click.argument('filename')
#
def get_file(filename):
    return filename
