"""
This module is responsible for manipulating input images.
"""
